function K = YOUR_DISTANCE(k,d1,d2,ind1,ind2,kerparam),

% Define your distance like this function, just replace YOUR_DISTANCE
%   and define the function below, between matrices
%   get_x(d2,ind2) and get_x(d1,ind1), e.g K = get_x(d2,ind2)*get_x(d1,ind1)';
%   for a linear distance.
  