data = readtable("df_filteredKS_geneset_all.csv");
data(:,:)
size(data)
data1 = readtable("iris.csv");
size(data1)
table2array(data1(:,1:4))
data1(:,5)
Y = strcmp(data1.variety,'Setosa');